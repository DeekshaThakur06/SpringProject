package com.bookStore.service;

//import java.util.List;

import com.bookStore.domain.Book;

public interface IBookService {
	Book save(Book book);
	Book update(Book book);
   void delete(String id);
    Book getById(String id);
   // List<Book> getAllBooks();
}
