package com.bookStore;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.bookStore.domain.Book;
import com.bookStore.repository.BookRepository;

@SpringBootApplication
public class EBookStoreApplication implements CommandLineRunner {

	@Autowired
	@Qualifier("bookRepository")
	 private BookRepository bookRepository;
	public static void main(String[] args) {
		SpringApplication.run(EBookStoreApplication.class, args);
		System.out.println("This is spring application......");
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		bookRepository.save(new Book("C++", "dEEKSHA", 2014));
		bookRepository.save(new Book( "C", "THAKUR", 2010));
		bookRepository.save(new Book( "C#", "dT", 2016));
		System.out.println(bookRepository.findAll());
		
		
	}

}
