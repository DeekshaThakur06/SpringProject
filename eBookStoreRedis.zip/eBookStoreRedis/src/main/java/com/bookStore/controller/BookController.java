package com.bookStore.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.bookStore.domain.Book;
import com.bookStore.service.IBookService;

@RestController
@Scope("request")
@RequestMapping("/books")
public class BookController {
	@Autowired
	@Qualifier("bookService")
	private IBookService bookService;
	
	@PutMapping(value="/updateBook",produces = {MediaType.APPLICATION_JSON_VALUE} )
	@ResponseStatus(code=HttpStatus.OK)
	public Book updateDetails(@RequestBody Book book) {
		return bookService.update(book);
	}
	@GetMapping(value="/book{id}", produces= {MediaType.APPLICATION_JSON_VALUE})
	public Book getById(@PathVariable String id) {
		return bookService.getById(id);
	}
	@DeleteMapping(value="/delete/{id}")
	@ResponseStatus(code=HttpStatus.NO_CONTENT)
    void deleteById(@PathVariable String id) {
    	bookService.delete(id);
    }
	@PostMapping(value="/insertBook",produces= {MediaType.APPLICATION_JSON_VALUE},consumes= {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code=HttpStatus.CREATED)
	public Book saveBook(@RequestBody Book book){
		return bookService.save(book);
	}
	
}
