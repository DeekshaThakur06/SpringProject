package com.BookStoreRedis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreRedisApplicationTests {

	@Test
	void contextLoads() {
	}

}
