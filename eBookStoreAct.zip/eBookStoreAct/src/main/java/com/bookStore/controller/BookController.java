package com.bookStore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bookStore.domain.Book;
import com.bookStore.service.IBookService;

@RestController
@Scope("request")
@RequestMapping("/book")
public class BookController {

	@Autowired
	@Qualifier("bookService")
	private IBookService bookService;
	
	@PostMapping(value="/insert",produces= {MediaType.APPLICATION_JSON_VALUE},consumes = {MediaType.APPLICATION_JSON_VALUE})
	public Book insertBook(@RequestBody Book book) {
		return bookService.save(book);
	
		
	}
	@PutMapping(value="/update",produces= {MediaType.APPLICATION_JSON_VALUE})
	public Book updateBook(@RequestBody Book book) {
		return bookService.update(book);
	}
	@DeleteMapping(value="/delete/{id}")
	void deleteBook(@PathVariable int id) {
		bookService.delete(id);
	}
	@GetMapping(value="/getAll",produces= {MediaType.APPLICATION_JSON_VALUE})
	List <Book> allBooks(){
		return bookService.getAllBooks();
	}
}
