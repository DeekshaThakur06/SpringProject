package com.bookStore;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.bookStore.domain.Book;
import com.bookStore.repository.BookRepository;
//import com.bookStore.service.IBookService;

@SpringBootApplication
public class EBookStoreActApplication implements CommandLineRunner {

	@Autowired
	@Qualifier("bookRepository")

	private BookRepository bookRepository;
	public static void main(String[] args) {
		SpringApplication.run(EBookStoreActApplication.class, args);
		System.out.println("Spring Application using Actuator.....");
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		bookRepository.save(new Book(0,"C","DENNIS",2014));
		bookRepository.save(new Book(0,"C++","ROBERT",2010));
		bookRepository.save(new Book(0,"HTML","TIM LEE",2016));
		bookRepository.save(new Book(0,"JAVA*","JAMES",2000));
		System.out.println(bookRepository.findAll());
		
	}

}
